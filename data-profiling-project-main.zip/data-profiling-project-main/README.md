
# Data Profiling Project

This project provides a tool to explore and analyze your data effortlessly .

## Features
- Upload CSV files or connect to a database to analyze your data.
- Generate detailed profiling reports to gain insights into your data.
- Download the genreated report .

## Installation
To install the required dependencies, run:
```
pip install -r requirements.txt
```

## Usage
1. Run the Streamlit app:
```
streamlit run DataProfiling.py
```
2. Use the navigation on the left to choose between uploading a file or connecting to a database.
3. Follow the prompts to generate and view data profiling reports.
4. scroll down to Download the repoprt
## Dependencies
- pandas
- streamlit
- ydata-profiling
- sqlite3
- base64

## License
This project is licensed under the MIT License.
