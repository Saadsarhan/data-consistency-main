#!/usr/bin/env python
# coding: utf-8

# In[1]:


#!/usr/bin/env python
# coding: utf-8

import pandas as pd
import streamlit as st
from ydata_profiling import ProfileReport
import sqlite3
import base64
# Load the logo image
logo_path = "SITE_LOGO.png"
logo_image = st.sidebar.image(logo_path, use_column_width=True)
POWERED_BY_SITE_IMAGE = "Powerd_By_SITE.png"
# Home page
# Home page
def home():
    st.markdown(
        """
        <style>
        .big-title {
            font-size: 72px;
            text-align: center;
            color: #375C42;
            text-shadow: 2px 2px #F2F2E9;
            margin-bottom: 50px;
        }
        .big-button-container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 60vh;
        }
        .big-button {
            font-size: 24px;
            padding: 20px 40px;
            background-color: #FFC300;
            color: white;
            border-radius: 10px;
            border: none;
            cursor: pointer;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
        }
        .big-button:hover {
            transform: translateY(-5px);
            box-shadow: 0px 6px 12px rgba(0, 0, 0, 0.2);
        }
        </style>
        """,
        unsafe_allow_html=True
    )

    st.markdown('<p class="big-title"> Explore Your Data!</p>', unsafe_allow_html=True)
    
    st.write("""
    This tool allows you to explore and analyze your data effortlessly. 
    You can either connect to a database using provided credentials or upload your data directly. 
    Once connected or uploaded, you can generate detailed reports to gain insights into your data. 
                    use the navigation on the left to get started!
    """)
    st.markdown("---")
    st.image(POWERED_BY_SITE_IMAGE, width=150)
    



# Reports page (formerly Data Options)
def reports():
    st.title('Reports')
    option = st.selectbox('Select your Data source', ('DB credentials', 'Upload data'))
    
    if option == 'DB credentials':
        # Logic for DB credentials
        st.write('DB credentials option selected')
        
        # Add your code here for DB credentials
        db_path = st.text_input('Database Path')
        username = st.text_input('Username')
        password = st.text_input('Password', type='password')
        table_name = st.text_input('Table Name')
        
        if st.button('Connect'):
            # Connect to the database and retrieve data
            try:
                # Connect to the database
                connection = sqlite3.connect(db_path)
                cursor = connection.cursor()
                
                # Execute the SQL query
                query = f"SELECT * FROM {table_name}"
                cursor.execute(query)
                
                # Fetch all the data
                data = cursor.fetchall()
                
                # Convert the data to a pandas DataFrame
                df = pd.DataFrame(data)
                
                # Generate the pandas profiling report
                pr = ProfileReport(df)
                report_html = pr.to_html()
                
                # Display the report
                st.components.v1.html(report_html, height=800, scrolling=True)
                
                # Close the cursor and the database connection
                cursor.close()
                connection.close()
            except Exception as e:
                st.error(f"Error occurred: {e}")
        
    elif option == 'Upload data':
        # Logic for uploading data
        st.write('Upload data option selected')
        
        uploaded_files = st.file_uploader("Upload CSV files", accept_multiple_files=True, type="csv")

        for idx, file in enumerate(uploaded_files):
            df = pd.read_csv(file)
            pr = ProfileReport(df)
            
            file_name = file.name
            report_button = st.sidebar.button(f"Generate Report for {file_name}", key=f"button_{idx}")
            
            if report_button:
                report_html = pr.to_html()
                st.components.v1.html(report_html, height=800, scrolling=True)  # Display the pandas-profiling report in the main area
                
                
                export_report(report_html, file_name)


def export_report(report_html, file_name="report"):
    b64 = base64.b64encode(report_html.encode()).decode()
    href = f'<a href="data:text/html;base64,{b64}" download="{file_name}.html">Download Report</a>'
    st.markdown(href, unsafe_allow_html=True)   
# Navigation function to go back to the Home page
def go_back_home():
    st.session_state['page'] = 'Home'

# Main App
def main():
    st.sidebar.title("Navigation")
    pages = ['Home', 'Reports']
    selected_page = st.sidebar.selectbox("Go to", pages)
    
    st.session_state.setdefault('page', 'Home')
    
    if selected_page == 'Home':
        home()
    elif selected_page == 'Reports':
        reports()

if __name__ == '__main__':
    main()


# In[ ]:
